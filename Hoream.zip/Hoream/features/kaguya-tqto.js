/*
* @Credit: Lexic team
* @Thank For Kang Ntuy
*/


function _0x364c(){const _0xf26262=['KANG NTUY']