let handler = async (m, { conn }) => {
const Script =`*• I N F O   S C R I P T :*\n• ${Func.texted("monospace", `Script ini gratis untuk di gunakan jadi jangan di perjualbelikan secara sepihak`)}\n*┌  ◦  Name:* Hoream AI\n*│  ◦  Version: *999*\n*│  ◦  Create at:* 5 Feb 2024\n*│  ◦ Link Download:* https://chat.whatsapp.com/EvOGcTRMOpbEypCaQcYNZf\n*└  ◦  Developer: *Kang Ntuy*\n\n*[ ✓ ] JIka ingin mendownloadnya ada di deskripsi GC Hoream AI*`

conn.reply(m.chat, Script, m, {
        contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363144038483540@newsletter',
                newsletterName: "[ ✓ ] Script free for all",
                serverMessageId: -1
            },
            businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid
            },
            forwardingScore: 256,
externalAdReply: {
        title: `HOREAM AI by TEUNGGAR`,
        body: wm,
        thumbnailUrl: "https://telegra.ph/file/63d9aacae5489d8dc079d.jpg",
        sourceUrl: "https://chat.whatsapp.com/EvOGcTRMOpbEypCaQcYNZf",
        mediaType: 1,
        renderLargerThumbnail: true
          }
        }
    })
}
handler.help = ["Script","sc","sourcecode"].map(a => a + ' *[get script here]*')
handler.tags = ["info","main"]
handler.command = ["Script","sc","sourcecode"]

module.exports = handler